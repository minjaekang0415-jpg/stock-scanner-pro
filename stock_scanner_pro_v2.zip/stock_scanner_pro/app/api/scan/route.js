import {scan} from '../../../lib/scanner';
export const dynamic='force-dynamic';
export const maxDuration=60;
export async function GET(req){const secret=process.env.CRON_SECRET;const auth=req.headers.get('authorization');if(secret&&auth!==`Bearer ${secret}`&&req.headers.get('user-agent')!=='vercel-cron/1.0')return Response.json({error:'Unauthorized'},{status:401});try{const result=await scan();return Response.json({ok:true,updatedAt:result.updatedAt,universeSize:result.universeSize,successCount:result.successCount,top10:result.top10})}catch(e){return Response.json({ok:false,error:e.message},{status:500})}}
